# hm-10-firmware

Official Link of the drivers:

http://www.jnhuamao.cn/download_rom_en.asp%3Fid%3D

Steps to Upgrade the firmware:

http://techienoise.com/upgrading-firmware-to-hm-10-cc2541-ble-4-0/
